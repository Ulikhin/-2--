//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    public static void main(String[] args) {
        int a = 6;
        int b = 0;

        int resultat1 = a + b;
        int resultat2 = a - b;
        int resultat3 = a * b;

        System.out.println(resultat1);
        System.out.println(resultat2);
        System.out.println(resultat3);


        try {
            int resultat4 = a / b;

            System.out.println(resultat4);}
        catch (ArithmeticException e){
            System.out.println("Делить на ноль - нельзя!");
        }

    }
}