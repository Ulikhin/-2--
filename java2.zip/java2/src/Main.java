//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Main {
    public static void main(String[] args) {


        String a = ("vova");


        String b = ("vasya");

        if (a.equals(b)) {
            System.out.println("строки идентичны.");
        } else {
            System.out.println("строки не идентичны.");}
    }
}